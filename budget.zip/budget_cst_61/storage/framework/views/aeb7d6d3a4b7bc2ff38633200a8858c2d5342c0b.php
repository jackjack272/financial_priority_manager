<table>
    <tr>
                 
        <?php
            use Illuminate\Support\Facades\Db;
            use Illuminate\Support\Facades\Auth;

            if(Auth::id() !=null){
            // see if admin 
            $is_admin=Db::table('users')
                ->where('id',Auth::id())
                ->select('is_admin')
                ->get();
            if($is_admin[0]->is_admin == 1){
                ?>
                    <td>
                        <a href="<?php echo e(route('admin.all_users')); ?>">
                            <button  class="button button-primary">
                                Admin pannel
                            </button>

                        </a>
                    </td>
                <?php
            }// theyll never know shhhh heheheh
        }
        ?>
    <?php if(auth()->guard()->check()): ?>
            <form id="logout" action="<?php echo e(route('logout')); ?>" method="POST">
            <td>
                <a onclick="document.getElementById('logout').submit();">
                    <button  class="button button-primary">
                        Logout
                    </button>
                </a>
                <?php echo csrf_field(); ?>
                </form>

            </td> 
        </tr>

        <tr>
            <td>
                <a href="<?php echo e(route('budget.show')); ?>">
                    <button  class="button button-primary">
                        people in budget
                    </button>
                </a>
            </td>

            
            <td>
                <a  href="<?php echo e(route('api.call')); ?>">
                    <button  class="button button-primary">
                        API
                    </button>
                </a>
            </td>

            <td>
                <a href="<?php echo e(route('budget.totals')); ?>">
                    <button  class="button button-primary">
                        see budget
                    </button>
                </a>
            </td>
        </tr>
    <?php endif; ?>


    <?php if(auth()->guard()->guest()): ?>
    <tr>
        <td>
            <label for="">log in </label>
            <a href="<?php echo e(route('login')); ?>">
                        <button>I already belong </button>

            </a>
        </td>
        <td>
            <label for="">register</label>
            <a href="<?php echo e(route('register')); ?>">
                <button>
                    show me your way
                </button>
            </a>
        </td>
    </tr>
    <tr>

        <td>
            <a href="<?php echo e(route('welcome')); ?>">
                <button>
                    budgeting works
                </button>
            </a>
        </td>

        <td>
            <a href="<?php echo e(route('savings')); ?>">
                <button>
                    saving works
                </button>
            </a>
        </td>

        <td>
            <a href="<?php echo e(route('trueNorth')); ?>">
                <button>
                    have a true north
                </button>
            </a>
        </td>

    </tr>
    <?php endif; ?>
        
    </tr>
</table><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/partials/navInside.blade.php ENDPATH**/ ?>