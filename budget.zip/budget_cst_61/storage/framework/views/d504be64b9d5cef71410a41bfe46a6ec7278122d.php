<?php $__env->startSection('title',$viewData['title'] ); ?>
<?php $__env->startSection('sub_title',$viewData['sub_title']); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="offEdge">
    <?php echo $viewData['content']; ?>

    <br>
    <img src="<?php echo e(asset('img/'.$viewData['image'])); ?>" alt="<?php echo e($viewData['imgAlt']); ?>">
</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\crist\OneDrive\Desktop\budget_cst_61\resources\views/welcomePage.blade.php ENDPATH**/ ?>