<?php $__env->startSection('title',$viewData['title']); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<form class="offEdge" method="post" action="<?php echo e(route('categories.update',['id'=>$viewData['cat']->id] )); ?>">
    <input name="budget_id" value="<?php echo e($viewData['budget_id']); ?>" hidden>


    <?php echo csrf_field(); ?>
    <table>
        <tr>    
            <td>
                <label name="name">What is the name of the category?</label>
                <input name="name" type="text" maxlength="40" value="<?php echo e($viewData['cat']->name); ?>">
            </td>
        </tr>

        <tr>
            <td>
                <label name="theme">What is the level of this item?</label>
                <?php $__currentLoopData = $viewData['needs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($level ==$viewData['cat']->theme): ?>
                        <input type="radio" value="<?php echo e($level); ?>" name="theme" checked><?php echo e($level); ?><br>  
                    <?php else: ?>
                        <input type="radio" value="<?php echo e($level); ?>" name="theme" ><?php echo e($level); ?><br>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </td>   
        </tr>
    
        <tr>
            <td>
                <input type="submit" value="submit">
            </td>       
        </tr>

    </table>
</form>




<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/categories/updateForm.blade.php ENDPATH**/ ?>