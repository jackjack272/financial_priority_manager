<?php $__env->startSection("title",$viewData['title']); ?>
<?php $__env->startSection('sub_title',$viewData['sub_title']); ?>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<hr>
<br>
<br>
<br>
<?php if(auth()->guard()->check()): ?>
<h4>Welcome <?php echo e($viewData['welcome_me']); ?> </h4>
<?php endif; ?>

<!-- I am the form table -->
<form method="post" action="<?php echo e(route('budget.add',['id'=>$viewData['current_user'] ])); ?>">
<p>This for dose not allow for duplicate names, and negative $ values. It will send you back.</p>    
<?php echo csrf_field(); ?>
<table>
    <thead>
        <tr>
            <td>Who is this budget For?</td>
            <td>What's your expected expence for the month?</td>
            <td>What's your monthly earning for the month?</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
               
                <input type="text" maxlength="30" name="for_who" placeholder="my self" >
            </td>

            <td>
               
                <input type="number" maxlength="30" name="total_outflow" placeholder="1500" >
            </td>

            <td>
                
                <input type="number" maxlength="30" name="total_inflow" placeholder="1200" >
            </td>
        </tr>
   
        <?php if(auth()->guard()->check()): ?>
        <tr>
            <td>
                <input type="submit" value="submit">
            </td>
        </tr>
        <?php endif; ?>

    </tbody>
</table>
</form>


<!-- I am the display table -->
<table>
    <?php if(auth()->guard()->check()): ?>
    <thead>
        <tr>
            <td>Budget for </td>
            <td>expected income  </td>
            <td>expected outflow </td>
            <td>Edit</td>
            <td>Delete</td>
        </tr>   
    </thead>

    <?php 
        $expected_income=0;
        $expected_expecnce=0;
    ?>

    <?php $__currentLoopData = $viewData['list_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbod>
        
        <?php
            $expected_income+=$data->total_inflow;
            $expected_expecnce+=$data->total_outflow;
        ?>        

        <tr>
            <td>
                <a href="<?php echo e(route('categories.show',['id'=>$data->id ])); ?>">
                    <button  class="button button-primary">
                        <?php echo e($data->for_who); ?>

                    </button>
                </a>
            </td>

            <td><?php echo e($data->total_inflow); ?></td>
            <td><?php echo e($data->total_outflow); ?></td>
            <td>
                <a href="<?php echo e(route('budget.updateForm',['id'=>$data->id] )); ?>">
                    <button  class="button button-primary">
                        edit 
                    </button>
                <a>
            </td>

            <td>
                <a href="<?php echo e(route('budget.delete',['id'=>$data->id ])); ?>">
                    <button  class="button button-primary">
                        delete 
                    </button>
                <a>
            </td>
        </tr>
    </tbod>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>

<div>
    Okay! so youre expecing <?php echo e($expected_expecnce); ?> cost with <?php echo e($expected_income); ?> income? <br>
    lets find out how close you are to the money!
    make your budget and click on the 'see budget' tab to get the reality! 
</div>




<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\budget_cst_61\resources\views/budget/listAll.blade.php ENDPATH**/ ?>