<?php $__env->startSection('title', $viewData['title']); ?>
<?php $__env->startSection('title', $viewData['title']); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="offEdge">

    <?php
        $actual_income=0;
        $actual_expense=0;
    ?>
    
    <tr> <!--category costs -->
        <b>Category Cost & Top 3 Cost Items</b>
        <?php $__currentLoopData = $viewData['levels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td>
                <?php echo e($item[0]); ?> are costing:<br>
                expenses: $<?php echo e($item[1]); ?> -<br>
                income: $<?php echo e($item[2]); ?><br>
                ---------------------<br>
                costs me: $<?php echo e($item[1]-$item[2]); ?>

            </td>

            <?php
                $actual_expense+=$item[1];
                $actual_income+=$item[2];
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>

    <tr> <!--heaviest items -->
       <?php $__currentLoopData = $viewData['levels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td>
            <?php echo e($item[0]); ?><br>
            
            <?php $__currentLoopData = $item[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heavy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               $<?php echo e($heavy->monthly_cost); ?> - <?php echo e($heavy->name); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>

    <tr> <!--misalanious -->
        <td>
            Out of pocket cost: <br>
            $<?php echo e($actual_expense - $actual_income); ?>

        </td>
    </tr>

    <tr><!--misalanious -->
    
        <td>
            Are the items above addressable?<br>
            Could you bargin hunt?
        </td>
    </tr>

  

</table>

I would reccomend that you save $<?php echo e($actual_income*.04); ?> per payperiod. <br>
If not now, lickly not tommorow, so on and so forth for a year or two... right? <br>
there will always be a next expense, a next want, a next ...
<br><br>

If you choose to split this on 2 pay checks youll need to save only  $<?php echo e($actual_expense/2); ?>.

 



<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/budget/totals.blade.php ENDPATH**/ ?>