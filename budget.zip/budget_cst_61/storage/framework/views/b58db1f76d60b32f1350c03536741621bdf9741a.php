</body>
<footer>
    3280-001 Laravel Project<br>
    Cristi Staci 12/04/2022<br>
</footer>
</html><?php /**PATH C:\Users\crist\OneDrive\Desktop\budget_cst_61\resources\views/partials/footer.blade.php ENDPATH**/ ?>